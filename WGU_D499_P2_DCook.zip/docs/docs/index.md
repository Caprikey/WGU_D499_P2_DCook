# WGU_D499_Project_2_Unsupervised_ML documentation!

## Description

A short description of the project.

## Commands

The Makefile contains the central entry points for common tasks related to this project.


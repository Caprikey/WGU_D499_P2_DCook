# Navigate to the directory containing the virtual environment
cd ".."

# Activate the virtual environment
.\\virtual_envs\D499_Project_2_Unsupervised_venv\Scripts\Activate.ps1